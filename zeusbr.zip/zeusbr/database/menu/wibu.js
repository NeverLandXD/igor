const wibu = (pushname, prefix, botName, ownerName) => {
        return `
╔══✪〘 Informações 〙✪══
║
║───────⊹⊱✫⊰⊹───────
║➩ ❍ wa.me/556993899391
║➩ ❍ Prefix: 「  ${prefix}  」
║➩ ❍ Criador: ${botName}
║➩ ❍ Nome: ${pushname}️
║➩ ❍ XP: ${reqXp}
║➩ ❍ Money: ${uangku}
───────⊹⊱✫⊰⊹───────


                     𝚉𝙴𝚄𝚂

───────⊹⊱✫⊰⊹───────
║➩ ❍ *${prefix}info*
║➩ ❍ *${prefix}blocklist*
║➩ ❍ *${prefix}chatlist*
║➩ ❍ *${prefix}ping*
║➩ ❍ *${prefix}bugreport*
║➩ ❍ *${prefix}neonime*
║➩ ❍ *${prefix}pokemon*
║➩ ❍ *${prefix}loli*
║➩ ❍ *${prefix}waifu*
║➩ ❍ *${prefix}randomanime*
║➩ ❍ *${prefix}husbu*
║➩ ❍ *${prefix}husbu2*
║➩ ❍ *${prefix}wait*
║➩ ❍ *${prefix}nekonime*
║───────⊹⊱✫⊰⊹───────`
}
exports.wibu = wibu
